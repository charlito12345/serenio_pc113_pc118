<?php

namespace Illuminate\Database\Query\Processors;

class MariaDbProcessor extends MySqlProcessor
{
    //
}
